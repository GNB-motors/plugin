import './assets/index.js-BdlBflxT.js';
